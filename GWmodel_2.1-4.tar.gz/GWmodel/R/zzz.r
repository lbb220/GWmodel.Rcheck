.onAttach <- function(lib, pkg) {
	packageStartupMessage("Welcome to GWmodel version 2.1-4.\nThe new version of GWmodel 2.1-4 now is ready", appendLF = FALSE)
  }